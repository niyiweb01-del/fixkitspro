# sge-verification

This is a placeholder deliverable. Replace this folder's contents with the real
kit files before going live (see /kit-source for the pattern used by existing kits).
